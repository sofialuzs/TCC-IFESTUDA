let perguntasProgInternet;
let pontuacao = 0;
let questaoAtual = 0;
let quantBarr = 0;
let respostasUsuario = [];
let questoesRespondidas = [];
const container = document.querySelector("#quiz-content");
const listaPerguntas = document.querySelector("#perguntas-lista");

document.addEventListener("DOMContentLoaded", function () {
  perguntasProgInternet = questoes.find(
    (q) => q.disciplina === "progInternet"
  ).perguntas;

  respostasUsuario = new Array(perguntasProgInternet.length).fill(null);
  questoesRespondidas = new Array(perguntasProgInternet.length).fill(false);

  exibirQuestao();
  exibirListaPerguntas();
});

function exibirQuestao() {
  const questao = perguntasProgInternet[questaoAtual];
  let conteudo = `<div class="questao"><h4>${questao.pergunta}</h4>`;

  questao.respostas.forEach((resposta, index) => {
    const isChecked = respostasUsuario[questaoAtual] === resposta ? "checked" : "";
    conteudo += `
      <div class="form-check resposta">
        <input class="form-check-input" type="radio" name="resposta" value="${resposta}" ${isChecked} ${questoesRespondidas[questaoAtual] ? 'disabled' : ''}>
        <label class="form-check-label">${resposta}</label>
      </div>`;
  });

  conteudo += `</div>`;
  container.innerHTML = conteudo;

  // Atualiza o estado do botão "Próxima"
  const botaoProxima = document.querySelector("#btn-next");
  botaoProxima.disabled = questoesRespondidas[questaoAtual]; // Desativa o botão se a questão já foi respondida

  atualizarQuestaoAtiva();
}

function proximaQuestao() {
  const respostaSelecionada = document.querySelector('input[name="resposta"]:checked');

  if (!respostaSelecionada) {
    alert("Por favor, selecione uma resposta.");
    return;
  }

  const resposta = respostaSelecionada.value;
  respostasUsuario[questaoAtual] = resposta;
  questoesRespondidas[questaoAtual] = true;

  // Desativa o botão "Próxima"
  const botaoProxima = document.querySelector("#btn-next");
  botaoProxima.disabled = true;

  if (resposta === perguntasProgInternet[questaoAtual].respostaCorreta) {
    marcarQuestaoCorreta(questaoAtual);
  } else {
    marcarQuestaoErrada(questaoAtual);
    mostrarRespostaCorreta(questaoAtual);
  }

  questaoAtual++;
  quantBarr++;
  barra(quantBarr);

  if (questaoAtual < perguntasProgInternet.length) {
    exibirQuestao();
  } else {
    finalizarQuiz();
  }
}

function finalizarQuiz() {
  pontuacao = 0;
  for (let i = 0; i < perguntasProgInternet.length; i++) {
    if (respostasUsuario[i] === perguntasProgInternet[i].respostaCorreta) {
      pontuacao += 10;
    }
  }

  container.innerHTML = `<h3>Parabéns! Você completou o quiz.</h3>
  <p>Sua pontuação final é ${pontuacao} pontos.</p>`;
  document.getElementById("btn-next").style.display = "none";
}

function exibirListaPerguntas() {
  perguntasProgInternet.forEach((questao, index) => {
    const item = document.createElement("button");
    item.classList.add("list-group-item", "list-group-item-action");
    item.textContent = `Questão ${index + 1}`;
    item.onclick = function () {
      questaoAtual = index;
      exibirQuestao();
    };

    if (respostasUsuario[index] !== null) {
      item.classList.add("respondida");
    }

    listaPerguntas.appendChild(item);
  });
}

function atualizarQuestaoAtiva() {
  const itens = listaPerguntas.querySelectorAll(".list-group-item");
  itens.forEach((item, index) => {
    item.classList.toggle("active", index === questaoAtual);
  });
}

function marcarQuestaoCorreta(index) {
  const itens = listaPerguntas.querySelectorAll(".list-group-item");
  itens[index].classList.add("correta");
  itens[index].classList.remove("errada");
}

function marcarQuestaoErrada(index) {
  const itens = listaPerguntas.querySelectorAll(".list-group-item");
  itens[index].classList.add("errada");
  itens[index].classList.remove("correta");
}

function mostrarRespostaCorreta(index) {
  const itens = listaPerguntas.querySelectorAll(".list-group-item");
  const questao = perguntasProgInternet[index];
  itens[index].innerHTML += `<br><span class="questao-incorreta">Correta: ${questao.respostaCorreta}</span>`;
}

function back() {
  window.location.href = "../../home/index.php";
}

function excluirSessao() {
  window.location.href = "../apagarSessao.php";
}

function barra(cont) {
  let porcernt = (cont / perguntasProgInternet.length) * 100;
  document.getElementById("barra").style.width = `${porcernt}%`;
  document.getElementById("barra").innerHTML = `${porcernt.toFixed(0)}%`;
}

