questoes = [
  {
    disciplina: "progInternet",
    perguntas: [
      {
        pergunta: "1. Qual tag HTML é usada para criar um link?",
        respostas: ["div", "link", "a", "p"],
        respostaCorreta: "a",
      },
      {
        pergunta: "2. Qual linguagem é usada para estilizar páginas web?",
        respostas: ["Python", "JavaScript", "CSS", "C++"],
        respostaCorreta: "CSS",
      },
      {
        pergunta: "3. O que significa CSS?",
        respostas: [
          "Cascading Style Sheets",
          "Central Style Sheets",
          "Creative Style Sheets",
          "Control Style Sheets",
        ],
        respostaCorreta: "Cascading Style Sheets",
      },
      {
        pergunta: "4. Em CSS, qual unidade de medida é relativa ao tamanho da fonte do elemento?",
        respostas: ["px", "em", "%", "rem"],
        respostaCorreta: "em",
      },
      {
        pergunta: "5. Qual é o símbolo usado para comentar uma linha de código em JavaScript?",
        respostas: ["//", "/*", "&lt!--", "#"],
        respostaCorreta: "//",
      },
      {
        pergunta: "6. Qual método JavaScript é usado para converter uma string em um número inteiro?",
        respostas: ["parseInt", "parseFloat", "toFixed", "toString"],
        respostaCorreta: "parseInt",
      },
      {
        pergunta: "7. Qual é a propriedade CSS usada para alterar a cor do texto?",
        respostas: [
          "background-color",
          "text-color",
          "color",
          "font-color"
        ],
        respostaCorreta: "color"
      },
      {
        pergunta: "8. O que faz a propriedade CSS display: flex;?",
        respostas: [
          "Define um layout de caixa de bloco.",
          "Alinha elementos de forma vertical na página.",
          "Cria um contêiner flexível para um layout de caixa, permitindo alinhamento e distribuição fácil dos itens.",
          "Aplica uma margem automática ao contêiner."
        ],
        respostaCorreta: "Cria um contêiner flexível para um layout de caixa, permitindo alinhamento e distribuição fácil dos itens."
      },
      {
        pergunta: "9. Qual é a finalidade da função document.getElementById() em JavaScript?",
        respostas: [
          "Cria um novo elemento HTML com o ID especificado.",
          "Retorna um elemento com o ID especificado do documento HTML.",
          "Define o ID de um elemento HTML.",
          "Remove o elemento com o ID especificado do documento HTML."
        ],
        respostaCorreta: "Retorna um elemento com o ID especificado do documento HTML."
      },
      {
        pergunta: "10. O que faz o método addEventListener() em JavaScript?",
        respostas: [
          "Adiciona um novo elemento ao DOM.",
          "Adiciona um evento a um elemento HTML e define a função a ser chamada quando o evento ocorre.",
          "Remove um evento de um elemento HTML.",
          "Modifica a aparência de um elemento HTML."
        ],
        respostaCorreta: "Adiciona um evento a um elemento HTML e define a função a ser chamada quando o evento ocorre."
      },
        {
          "pergunta": "11. Qual tag HTML é usada para inserir uma imagem?",
          "respostas": ["image", "img", "src", "picture"],
          "respostaCorreta": "img"
        },
        {
          "pergunta": "12. Qual atributo HTML é utilizado para especificar o endereço de uma imagem?",
          "respostas": ["src", "alt", "href", "title"],
          "respostaCorreta": "src"
        },
        {
          "pergunta": "13. Qual método JavaScript é usado para transformar uma string em letras maiúsculas?",
          "respostas": ["toUpperCase", "toLowerCase", "capitalize", "split"],
          "respostaCorreta": "toUpperCase"
        },
        {
          "pergunta": "14. Em CSS, qual propriedade é usada para alterar o fundo de um elemento?",
          "respostas": ["background", "bgcolor", "color", "foreground"],
          "respostaCorreta": "background"
        },
        {
          "pergunta": "15. Qual é a função da tag <head> em HTML?",
          "respostas": ["Contém o conteúdo visível da página.", "Contém os metadados e links para recursos externos.", "Define o título da página.", "Define o conteúdo de navegação."],
          "respostaCorreta": "Contém os metadados e links para recursos externos."
        },
        {
          "pergunta": "16. O que a propriedade CSS 'box-sizing' faz?",
          "respostas": [
            "Define a largura de um elemento.",
            "Controla como as larguras e alturas de elementos são calculadas.",
            "Determina a cor da borda de um elemento.",
            "Define o espaço interno de um elemento."
          ],
          "respostaCorreta": "Controla como as larguras e alturas de elementos são calculadas."
        },
        {
          "pergunta": "17. O que é um 'callback' em JavaScript?",
          "respostas": [
            "Uma função que é passada como argumento para outra função.",
            "Uma função que retorna um valor.",
            "Uma função que modifica o DOM.",
            "Uma função que é executada em loop."
          ],
          "respostaCorreta": "Uma função que é passada como argumento para outra função."
        },
        {
          "pergunta": "18. O que a tag <link> é usada para fazer em HTML?",
          "respostas": [
            "Definir um link para outro documento HTML.",
            "Incluir um arquivo de estilo CSS externo.",
            "Incluir uma imagem no documento.",
            "Criar um botão de navegação."
          ],
          "respostaCorreta": "Incluir um arquivo de estilo CSS externo."
        },
        {
          "pergunta": "19. Qual tag HTML é usada para criar uma lista ordenada?",
          "respostas": ["<ol>", "<ul>", "<li>", "<dl>"],
          "respostaCorreta": "<ol>"
        },
        {
          "pergunta": "20. O que é o DOM em JavaScript?",
          "respostas": [
            "Uma biblioteca de manipulação de eventos.",
            "Uma API para manipular HTML e XML.",
            "Um método de depuração.",
            "Um tipo de estrutura de dados."
          ],
          "respostaCorreta": "Uma API para manipular HTML e XML."
        },
        {
          "pergunta": "21. O que é uma 'promise' em JavaScript?",
          "respostas": [
            "Uma função que retarda a execução do código.",
            "Um tipo de loop.",
            "Um objeto que representa a eventual conclusão ou falha de uma operação assíncrona.",
            "Uma função para manipulação de erros."
          ],
          "respostaCorreta": "Um objeto que representa a eventual conclusão ou falha de uma operação assíncrona."
        },
        {
          "pergunta": "22. Qual tag HTML é usada para criar uma tabela?",
          "respostas": ["<table>", "<tr>", "<td>", "<th>"],
          "respostaCorreta": "<table>"
        },
        {
          "pergunta": "23. Qual é a principal diferença entre as tags <div> e <span> em HTML?",
          "respostas": [
            "A tag <div> é um contêiner de bloco, enquanto <span> é um contêiner em linha.",
            "A tag <span> é usada para listas, enquanto <div> é para parágrafos.",
            "A tag <div> é usada apenas para textos, enquanto <span> é para imagens.",
            "Não há diferença entre as duas tags."
          ],
          "respostaCorreta": "A tag <div> é um contêiner de bloco, enquanto <span> é um contêiner em linha."
        },
        {
          "pergunta": "24. O que significa o termo 'responsivo' em design web?",
          "respostas": [
            "O design se adapta a diferentes tamanhos de tela e dispositivos.",
            "O design usa animações e transições.",
            "O design é focado em gráficos de alta qualidade.",
            "O design usa uma paleta de cores fixa."
          ],
          "respostaCorreta": "O design se adapta a diferentes tamanhos de tela e dispositivos."
        },
        {
          "pergunta": "25. Qual é o efeito da propriedade 'float' em CSS?",
          "respostas": [
            "Faz com que um elemento se mova para a esquerda ou para a direita do seu contêiner.",
            "Faz com que um elemento seja exibido como uma caixa flexível.",
            "Ajusta a altura de um elemento.",
            "Alinha o texto em um parágrafo."
          ],
          "respostaCorreta": "Faz com que um elemento se mova para a esquerda ou para a direita do seu contêiner."
        },
        {
          "pergunta": "26. O que faz a função 'setTimeout' em JavaScript?",
          "respostas": [
            "Define um tempo limite para uma função ser executada.",
            "Repete a execução de uma função.",
            "Adiciona um evento a um elemento HTML.",
            "Cria um loop infinito."
          ],
          "respostaCorreta": "Define um tempo limite para uma função ser executada."
        },
        {
          "pergunta": "27. Qual é a finalidade da propriedade CSS 'position'?",
          "respostas": [
            "Define como os elementos são posicionados na página.",
            "Define a largura dos elementos.",
            "Define o alinhamento do texto.",
            "Define a cor do texto."
          ],
          "respostaCorreta": "Define como os elementos são posicionados na página."
        },
        {
          "pergunta": "28. Em HTML, qual tag é usada para criar um formulário?",
          "respostas": ["<form>", "<input>", "<textarea>", "<button>"],
          "respostaCorreta": "<form>"
        },
        {
          "pergunta": "29. O que é o 'localStorage' em JavaScript?",
          "respostas": [
            "Uma forma de armazenar dados temporários no navegador.",
            "Uma função para gerenciar cookies.",
            "Uma API para trabalhar com banco de dados no servidor.",
            "Uma ferramenta para depuração."
          ],
          "respostaCorreta": "Uma forma de armazenar dados temporários no navegador."
        },
        {
          "pergunta": "30. O que é uma 'função anônima' em JavaScript?",
          "respostas": [
            "Uma função que não tem nome e é geralmente usada como argumento de outra função.",
            "Uma função que não retorna valores.",
            "Uma função que não recebe parâmetros.",
            "Uma função que é declarada dentro de um loop."
          ],
          "respostaCorreta": "Uma função que não tem nome e é geralmente usada como argumento de outra função."
        },
        {
          "pergunta": "31. O que faz o atributo 'href' em HTML?",
          "respostas": [
            "Especifica o destino de um link.",
            "Define o título de uma página.",
            "Especifica o caminho da imagem.",
            "Aplica estilo a um link."
          ],
          "respostaCorreta": "Especifica o destino de um link."
        },
        {
          "pergunta": "32. Qual é a principal diferença entre os métodos 'getElementById' e 'getElementsByClassName' em JavaScript?",
          "respostas": [
            "'getElementById' retorna um único elemento, enquanto 'getElementsByClassName' retorna uma coleção de elementos.",
            "'getElementById' retorna uma lista de elementos, enquanto 'getElementsByClassName' retorna um único elemento.",
            "Não há diferença, ambos fazem a mesma coisa.",
            "'getElementById' é usado para manipular eventos."
          ],
          "respostaCorreta": "'getElementById' retorna um único elemento, enquanto 'getElementsByClassName' retorna uma coleção de elementos."
        },
        {
          "pergunta": "33. O que é o 'this' em JavaScript?",
          "respostas": [
            "Refere-se ao objeto que está chamando o método.",
            "Uma variável global.",
            "Uma função anônima.",
            "O escopo global da aplicação."
          ],
          "respostaCorreta": "Refere-se ao objeto que está chamando o método."
        },
        {
          "pergunta": "34. Qual método JavaScript é usado para transformar uma string em um número decimal?",
          "respostas": ["parseInt", "parseFloat", "toString", "toNumber"],
          "respostaCorreta": "parseFloat"
        },
        {
          "pergunta": "35. O que faz o método 'Array.push()' em JavaScript?",
          "respostas": [
            "Adiciona um elemento ao final de um array.",
            "Remove o último elemento de um array.",
            "Verifica se um elemento existe em um array.",
            "Adiciona um elemento no início de um array."
          ],
          "respostaCorreta": "Adiciona um elemento ao final de um array."
        },
        {
          "pergunta": "36. O que significa a sigla 'API'?",
          "respostas": [
            "Application Programming Interface",
            "Application Program Interface",
            "Advanced Programming Interface",
            "Automated Programming Interface"
          ],
          "respostaCorreta": "Application Programming Interface"
        },
        {
          "pergunta": "37. O que é um 'loop' em programação?",
          "respostas": [
            "Uma estrutura que permite repetir um conjunto de instruções.",
            "Uma função que é executada apenas uma vez.",
            "Uma técnica para fazer chamadas assíncronas.",
            "Um método para exibir conteúdo na página."
          ],
          "respostaCorreta": "Uma estrutura que permite repetir um conjunto de instruções."
        },
        {
          "pergunta": "38. O que faz a propriedade 'z-index' em CSS?",
          "respostas": [
            "Controla a sobreposição de elementos na página.",
            "Define a largura de um elemento.",
            "Define a cor de fundo de um elemento.",
            "Define a margem de um elemento."
          ],
          "respostaCorreta": "Controla a sobreposição de elementos na página."
        },
        {
          "pergunta": "39. O que é uma variável global em JavaScript?",
          "respostas": [
            "Uma variável definida fora de qualquer função e acessível em todo o código.",
            "Uma variável que é visível apenas dentro de uma função.",
            "Uma variável definida dentro de um loop.",
            "Uma variável usada apenas em funções assíncronas."
          ],
          "respostaCorreta": "Uma variável definida fora de qualquer função e acessível em todo o código."
        },
        {
          "pergunta": "40. Qual método em JavaScript permite adicionar um ou mais elementos no início de um array?",
          "respostas": [
            "push",
            "pop",
            "unshift",
            "shift"
          ],
          "respostaCorreta": "unshift"
        }, 
        {
          "pergunta": "41. Qual tag HTML é usada para criar um parágrafo?",
          "respostas": ["<p>", "<div>", "<section>", "<span>"],
          "respostaCorreta": "<p>"
        },
        {
          "pergunta": "42. O que é o 'npm' em JavaScript?",
          "respostas": [
            "Uma ferramenta de gerenciamento de pacotes.",
            "Um tipo de framework.",
            "Uma linguagem de programação.",
            "Uma biblioteca para manipulação do DOM."
          ],
          "respostaCorreta": "Uma ferramenta de gerenciamento de pacotes."
        },
        {
          "pergunta": "43. Qual é a função da tag <meta> em HTML?",
          "respostas": [
            "Define metadados sobre a página, como descrições e palavras-chave.",
            "Define o conteúdo de navegação da página.",
            "Especifica a cor de fundo da página.",
            "Cria links entre páginas."
          ],
          "respostaCorreta": "Define metadados sobre a página, como descrições e palavras-chave."
        },
        {
          "pergunta": "44. Em CSS, qual propriedade é usada para ajustar o espaçamento entre as letras?",
          "respostas": ["letter-spacing", "word-spacing", "text-indent", "line-height"],
          "respostaCorreta": "letter-spacing"
        },
        {
          "pergunta": "45. O que é uma função recursiva em JavaScript?",
          "respostas": [
            "Uma função que se chama novamente dentro de seu próprio corpo.",
            "Uma função que é chamada apenas uma vez.",
            "Uma função que altera o valor de uma variável global.",
            "Uma função que não retorna valores."
          ],
          "respostaCorreta": "Uma função que se chama novamente dentro de seu próprio corpo."
        },
        {
          "pergunta": "46. O que é uma variável local em JavaScript?",
          "respostas": [
            "Uma variável que é definida dentro de uma função e só é acessível nela.",
            "Uma variável que pode ser acessada globalmente.",
            "Uma variável usada para armazenar o tempo de execução.",
            "Uma variável usada para armazenar dados do servidor."
          ],
          "respostaCorreta": "Uma variável que é definida dentro de uma função e só é acessível nela."
        },
        {
          "pergunta": "47. O que a propriedade CSS 'padding' controla?",
          "respostas": [
            "O espaço interno entre o conteúdo de um elemento e sua borda.",
            "A cor de fundo de um elemento.",
            "O alinhamento de texto.",
            "A margem externa de um elemento."
          ],
          "respostaCorreta": "O espaço interno entre o conteúdo de um elemento e sua borda."
        },
        {
          "pergunta": "48. Em HTML, o que faz a tag <br>?",
          "respostas": [
            "Insere uma quebra de linha.",
            "Define uma quebra de parágrafo.",
            "Cria um link.",
            "Define uma linha de divisão."
          ],
          "respostaCorreta": "Insere uma quebra de linha."
        },
        {
          "pergunta": "49. Qual é o método em JavaScript para adicionar um item no final de um array?",
          "respostas": [
            "push",
            "pop",
            "shift",
            "unshift"
          ],
          "respostaCorreta": "push"
        },
        {
          "pergunta": "50. Qual é a diferença entre '==' e '===' em JavaScript?",
          "respostas": [
            "'==' compara valores, enquanto '===' compara valores e tipos.",
            "'==' compara apenas tipos, enquanto '===' compara valores.",
            "'==' verifica a referência do objeto, enquanto '===' compara o conteúdo.",
            "'==' e '===' são idênticos."
          ],
          "respostaCorreta": "'==' compara valores, enquanto '===' compara valores e tipos."
        },
        {
          "pergunta": "51. Qual método JavaScript é usado para remover o último item de um array?",
          "respostas": [
            "pop",
            "push",
            "shift",
            "unshift"
          ],
          "respostaCorreta": "pop"
        },
        {
          "pergunta": "52. O que faz a propriedade CSS 'float'?",
          "respostas": [
            "Faz com que um elemento flutue para a esquerda ou direita, permitindo que o conteúdo flua ao seu redor.",
            "Define o tamanho da fonte.",
            "Faz com que o conteúdo dentro de um elemento seja centralizado.",
            "Ajusta a cor de fundo."
          ],
          "respostaCorreta": "Faz com que um elemento flutue para a esquerda ou direita, permitindo que o conteúdo flua ao seu redor."
        },
        {
          "pergunta": "53. O que a função 'JSON.parse()' faz em JavaScript?",
          "respostas": [
            "Transforma uma string JSON em um objeto JavaScript.",
            "Transforma um objeto JavaScript em uma string JSON.",
            "Exclui um objeto JSON.",
            "Verifica se um objeto é válido JSON."
          ],
          "respostaCorreta": "Transforma uma string JSON em um objeto JavaScript."
        },
        {
          "pergunta": "54. O que é o conceito de 'hoisting' em JavaScript?",
          "respostas": [
            "A elevação de declarações de variáveis e funções para o topo do escopo.",
            "A capacidade de armazenar dados em cache.",
            "A organização de arquivos em módulos.",
            "O carregamento assíncrono de funções."
          ],
          "respostaCorreta": "A elevação de declarações de variáveis e funções para o topo do escopo."
        },
        {
          "pergunta": "55. O que faz a propriedade CSS 'border-radius'?",
          "respostas": [
            "Define o arredondamento das bordas de um elemento.",
            "Altera a cor da borda de um elemento.",
            "Define a largura das bordas de um elemento.",
            "Remove as bordas de um elemento."
          ],
          "respostaCorreta": "Define o arredondamento das bordas de um elemento."
        },
        {
          "pergunta": "56. O que faz a função 'console.log()' em JavaScript?",
          "respostas": [
            "Exibe informações no console de depuração.",
            "Armazena valores em uma variável.",
            "Envia uma mensagem para o servidor.",
            "Altera o conteúdo de um elemento HTML."
          ],
          "respostaCorreta": "Exibe informações no console de depuração."
        },
        {
          "pergunta": "57. O que significa 'HTTP'?",
          "respostas": [
            "HyperText Transfer Protocol",
            "HyperText Transaction Protocol",
            "HyperType Transfer Protocol",
            "HyperText Transmission Protocol"
          ],
          "respostaCorreta": "HyperText Transfer Protocol"
        },
        {
          "pergunta": "58. Qual a função do atributo 'alt' em uma tag <img>?",
          "respostas": [
            "Fornece uma descrição alternativa caso a imagem não carregue.",
            "Define a cor da borda da imagem.",
            "Define a altura da imagem.",
            "Especifica a largura da imagem."
          ],
          "respostaCorreta": "Fornece uma descrição alternativa caso a imagem não carregue."
        },
        {
          "pergunta": "59. O que faz a propriedade CSS 'text-align'?",
          "respostas": [
            "Define o alinhamento do texto dentro de um elemento.",
            "Define o tamanho do texto.",
            "Define a cor do texto.",
            "Aplica uma sombra ao texto."
          ],
          "respostaCorreta": "Define o alinhamento do texto dentro de um elemento."
        },
        {
          "pergunta": "60. O que faz a tag <iframe> em HTML?",
          "respostas": [
            "Incorpora um documento externo dentro da página.",
            "Cria uma nova página de navegação.",
            "Define um link para um documento externo.",
            "Exibe um formulário de entrada."
          ],
          "respostaCorreta": "Incorpora um documento externo dentro da página."
        },
        {
          "pergunta": "61. O que é o conceito de 'AJAX'?",
          "respostas": [
            "Uma técnica para atualizar partes de uma página web sem recarregar toda a página.",
            "Uma técnica de compressão de imagens.",
            "Uma maneira de criptografar dados em um site.",
            "Uma forma de redirecionar usuários para outras páginas."
          ],
          "respostaCorreta": "Uma técnica para atualizar partes de uma página web sem recarregar toda a página."
        },
        {
          "pergunta": "62. Qual é a principal diferença entre 'let' e 'var' em JavaScript?",
          "respostas": [
            "'let' tem escopo de bloco, enquanto 'var' tem escopo de função.",
            "'let' é usado apenas em funções, enquanto 'var' pode ser usado em qualquer lugar.",
            "'let' é uma versão mais antiga de 'var'.",
            "'let' e 'var' são idênticos."
          ],
          "respostaCorreta": "'let' tem escopo de bloco, enquanto 'var' tem escopo de função."
        },
        {
          "pergunta": "63. O que é o modelo de caixa em CSS?",
          "respostas": [
            "Uma maneira de calcular o tamanho de um elemento considerando suas margens, bordas, padding e conteúdo.",
            "Um modelo de layout para alinhas os itens.",
            "Uma técnica de animação em CSS.",
            "Uma ferramenta para modificar a cor de um elemento."
          ],
          "respostaCorreta": "Uma maneira de calcular o tamanho de um elemento considerando suas margens, bordas, padding e conteúdo."
        },
        {
          "pergunta": "64. O que significa o termo 'responsive design'?",
          "respostas": [
            "Uma técnica para criar sites que se adaptam a diferentes tamanhos de tela.",
            "Um tipo de animação em CSS.",
            "Uma forma de ajustar as imagens automaticamente.",
            "Uma técnica para otimizar o tempo de carregamento."
          ],
          "respostaCorreta": "Uma técnica para criar sites que se adaptam a diferentes tamanhos de tela."
        },
        {
          "pergunta": "65. O que a propriedade 'position' faz em CSS?",
          "respostas": [
            "Controla o posicionamento de um elemento na página.",
            "Controla a cor de um elemento.",
            "Controla o alinhamento de texto.",
            "Controla o tamanho de uma imagem."
          ],
          "respostaCorreta": "Controla o posicionamento de um elemento na página."
        },
        {
          "pergunta": "66. O que significa 'SQL'?",
          "respostas": [
            "Structured Query Language",
            "Simple Query Language",
            "Standard Query Language",
            "Scripting Query Language"
          ],
          "respostaCorreta": "Structured Query Language"
        },
        {
          "pergunta": "67. O que é 'localStorage' em JavaScript?",
          "respostas": [
            "Uma maneira de armazenar dados localmente no navegador do usuário.",
            "Uma função para armazenar dados em servidores.",
            "Uma técnica de compressão de arquivos.",
            "Uma ferramenta para verificar a segurança de um site."
          ],
          "respostaCorreta": "Uma maneira de armazenar dados localmente no navegador do usuário."
        },
        {
          "pergunta": "68. O que significa a sigla 'JSON'?",
          "respostas": [
            "JavaScript Object Notation",
            "Java Standard Object Notation",
            "JavaScript Online Notation",
            "Just Simple Object Notation"
          ],
          "respostaCorreta": "JavaScript Object Notation"
        },
        {
          "pergunta": "69. O que é um evento em JavaScript?",
          "respostas": [
            "Uma ação que ocorre no navegador, como um clique ou envio de formulário.",
            "Uma variável que armazena um valor.",
            "Uma função que é chamada quando a página carrega.",
            "Uma forma de modificar o layout."
          ],
          "respostaCorreta": "Uma ação que ocorre no navegador, como um clique ou envio de formulário."
        },
        {
          "pergunta": "70. Qual a principal diferença entre 'null' e 'undefined' em JavaScript?",
          "respostas": [
            "'null' é um valor atribuído explicitamente, enquanto 'undefined' significa que uma variável não foi definida.",
            "'null' e 'undefined' são idênticos.",
            "'null' é uma referência nula, enquanto 'undefined' é uma função não definida.",
            "'null' é usado apenas para números, enquanto 'undefined' é usado para strings."
          ],
          "respostaCorreta": "'null' é um valor atribuído explicitamente, enquanto 'undefined' significa que uma variável não foi definida."
        },
        {
          "pergunta": "71. O que faz a tag <h1> em HTML?",
          "respostas": [
            "Define o título principal de uma página.",
            "Insere uma imagem.",
            "Cria um link.",
            "Cria um parágrafo."
          ],
          "respostaCorreta": "Define o título principal de uma página."
        },
        {
          "pergunta": "72. O que faz a propriedade CSS 'overflow'?",
          "respostas": [
            "Controla o que acontece quando o conteúdo de um elemento ultrapassa seu tamanho.",
            "Altera a cor de fundo de um elemento.",
            "Define a altura de um elemento.",
            "Controla a borda de um elemento."
          ],
          "respostaCorreta": "Controla o que acontece quando o conteúdo de um elemento ultrapassa seu tamanho."
        },
        {
          "pergunta": "73. O que significa o termo 'DOM' em JavaScript?",
          "respostas": [
            "Document Object Model",
            "Data Object Model",
            "Digital Object Model",
            "Document Online Model"
          ],
          "respostaCorreta": "Document Object Model"
        },
        {
          "pergunta": "74. Qual é o propósito do método 'addEventListener()' em JavaScript?",
          "respostas": [
            "Associa um evento a um elemento HTML.",
            "Remove um evento de um elemento HTML.",
            "Altera o conteúdo de um elemento HTML.",
            "Define a posição de um elemento na página."
          ],
          "respostaCorreta": "Associa um evento a um elemento HTML."
        },
        {
          "pergunta": "75. Em JavaScript, qual é a função de 'parseFloat()'?",
          "respostas": [
            "Converte uma string em um número decimal.",
            "Converte uma string em um número inteiro.",
            "Armazena um número com ponto flutuante.",
            "Transforma um número em uma string."
          ],
          "respostaCorreta": "Converte uma string em um número decimal."
        },
        {
          "pergunta": "76. O que é um 'callback' em JavaScript?",
          "respostas": [
            "Uma função passada como argumento para outra função, que será executada depois.",
            "Uma variável que armazena dados assíncronos.",
            "Uma estrutura de dados que armazena funções.",
            "Uma função que é executada antes de outra."
          ],
          "respostaCorreta": "Uma função passada como argumento para outra função, que será executada depois."
        },
        {
          "pergunta": "77. O que a propriedade CSS 'display: grid' faz?",
          "respostas": [
            "Cria um layout de grade para organizar os itens em linhas e colunas.",
            "Ajusta a largura de um elemento.",
            "Alinha o texto dentro de um elemento.",
            "Controla o tamanho da fonte de um elemento."
          ],
          "respostaCorreta": "Cria um layout de grade para organizar os itens em linhas e colunas."
        },
        {
          "pergunta": "78. O que a função 'document.querySelector()' faz em JavaScript?",
          "respostas": [
            "Retorna o primeiro elemento que corresponde ao seletor CSS especificado.",
            "Altera o conteúdo de um elemento HTML.",
            "Cria um novo elemento HTML.",
            "Exclui um elemento da página."
          ],
          "respostaCorreta": "Retorna o primeiro elemento que corresponde ao seletor CSS especificado."
        },
        {
          "pergunta": "79. O que significa o termo 'AJAX'?",
          "respostas": [
            "Asynchronous JavaScript and XML",
            "Advanced JavaScript and XML",
            "Active JavaScript and XML",
            "Automatic JavaScript and XML"
          ],
          "respostaCorreta": "Asynchronous JavaScript and XML"
        },
        {
          "pergunta": "80. O que é o 'flexbox' em CSS?",
          "respostas": [
            "Uma técnica para criar layouts flexíveis e responsivos.",
            "Uma forma de animar elementos.",
            "Uma técnica para criar barras de rolagem.",
            "Uma propriedade para definir o tamanho de fontes."
          ],
          "respostaCorreta": "Uma técnica para criar layouts flexíveis e responsivos."
        },
        {
          "pergunta": "81. O que significa o termo 'localStorage' em JavaScript?",
          "respostas": [
            "Uma maneira de armazenar dados localmente no navegador.",
            "Uma técnica para armazenar dados em servidores.",
            "Uma função para manipular cookies.",
            "Uma estrutura de dados para armazenamento em tempo real."
          ],
          "respostaCorreta": "Uma maneira de armazenar dados localmente no navegador."
        },
        {
          "pergunta": "82. Qual é a diferença entre 'class' e 'id' em HTML?",
          "respostas": [
            "'class' pode ser atribuída a múltiplos elementos, enquanto 'id' é única para cada elemento.",
            "'class' é usada para definir atributos, enquanto 'id' define estilos.",
            "'id' não pode ser usado em tags, enquanto 'class' pode.",
            "'class' é sempre global, enquanto 'id' é local."
          ],
          "respostaCorreta": "'class' pode ser atribuída a múltiplos elementos, enquanto 'id' é única para cada elemento."
        },
        {
          "pergunta": "83. Qual método JavaScript é usado para remover o primeiro item de um array?",
          "respostas": [
            "shift",
            "pop",
            "unshift",
            "push"
          ],
          "respostaCorreta": "shift"
        },
        {
          "pergunta": "84. O que a tag <input> faz em HTML?",
          "respostas": [
            "Cria um campo de entrada de dados.",
            "Define uma área de texto.",
            "Cria uma tabela.",
            "Cria uma imagem."
          ],
          "respostaCorreta": "Cria um campo de entrada de dados."
        },
        {
          "pergunta": "85. O que significa 'SEO' no contexto de websites?",
          "respostas": [
            "Search Engine Optimization",
            "Secure Encryption Online",
            "Server End Optimization",
            "Simple Electronic Optimization"
          ],
          "respostaCorreta": "Search Engine Optimization"
        },
        {
          "pergunta": "86. O que faz a propriedade 'box-sizing' em CSS?",
          "respostas": [
            "Controla como o tamanho de um elemento é calculado, incluindo bordas e padding.",
            "Controla a altura de um elemento.",
            "Controla a cor de fundo.",
            "Controla a visibilidade de um elemento."
          ],
          "respostaCorreta": "Controla como o tamanho de um elemento é calculado, incluindo bordas e padding."
        },
        {
          "pergunta": "87. O que faz o operador '===' em JavaScript?",
          "respostas": [
            "Compara valores e tipos de dados de maneira estrita.",
            "Compara apenas os valores de duas variáveis.",
            "Atribui um valor a uma variável.",
            "Define uma função."
          ],
          "respostaCorreta": "Compara valores e tipos de dados de maneira estrita."
        },
        {
          "pergunta": "88. O que faz a propriedade CSS 'visibility'?",
          "respostas": [
            "Controla a visibilidade de um elemento na página.",
            "Controla o alinhamento de um elemento.",
            "Altera a cor de um elemento.",
            "Define o posicionamento de um elemento."
          ],
          "respostaCorreta": "Controla a visibilidade de um elemento na página."
        },
        {
          "pergunta": "89. Qual é a finalidade da função 'setInterval()' em JavaScript?",
          "respostas": [
            "Executa uma função repetidamente em intervalos de tempo definidos.",
            "Retorna a data e hora atuais.",
            "Altera a cor de fundo de um elemento.",
            "Define uma variável no escopo global."
          ],
          "respostaCorreta": "Executa uma função repetidamente em intervalos de tempo definidos."
        },
        {
          "pergunta": "90. O que é um 'promise' em JavaScript?",
          "respostas": [
            "Uma forma de lidar com operações assíncronas.",
            "Uma função que retorna um valor.",
            "Uma estrutura de dados que armazena objetos.",
            "Uma maneira de criar animações."
          ],
          "respostaCorreta": "Uma forma de lidar com operações assíncronas."
        },
        {
          "pergunta": "91. O que significa 'CRUD' em programação?",
          "respostas": [
            "Create, Read, Update, Delete",
            "Create, Reset, Undo, Delete",
            "Connect, Retrieve, Update, Deliver",
            "Compute, Read, Unify, Deliver"
          ],
          "respostaCorreta": "Create, Read, Update, Delete"
        },
        {
          "pergunta": "92. Qual é a função da propriedade CSS 'position: absolute'?",
          "respostas": [
            "Posiciona o elemento em relação ao seu primeiro antecessor posicionado.",
            "Posiciona o elemento no topo da página.",
            "Posiciona o elemento dentro de um flex container.",
            "Posiciona o elemento em relação à tela."
          ],
          "respostaCorreta": "Posiciona o elemento em relação ao seu primeiro antecessor posicionado."
        },
        {
          "pergunta": "93. Qual é a principal diferença entre '== e ===' em JavaScript?",
          "respostas": [
            "'==' compara apenas os valores, enquanto '===' compara os valores e os tipos de dados.",
            "'==' é usado apenas para strings, enquanto '===' é para números.",
            "'==' é para operadores aritméticos, enquanto '===' é para operadores lógicos.",
            "'==' compara objetos, enquanto '===' compara valores."
          ],
          "respostaCorreta": "'==' compara apenas os valores, enquanto '===' compara os valores e os tipos de dados."
        },
        {
          "pergunta": "94. O que é a propriedade 'z-index' em CSS?",
          "respostas": [
            "Controla a sobreposição de elementos na página.",
            "Alinha elementos em uma grid.",
            "Ajusta a cor de um elemento.",
            "Modifica a largura de um elemento."
          ],
          "respostaCorreta": "Controla a sobreposição de elementos na página."
        },
        {
          "pergunta": "95. O que significa o termo 'API' em programação?",
          "respostas": [
            "Application Programming Interface",
            "Active Programming Integration",
            "Automatic Programming Interface",
            "Advanced Program Interaction"
          ],
          "respostaCorreta": "Application Programming Interface"
        },
        {
          "pergunta": "96. O que é o 'Event Loop' em JavaScript?",
          "respostas": [
            "O ciclo que gerencia a execução de tarefas assíncronas.",
            "A estrutura para manipular erros.",
            "Uma função que executa código sincrono.",
            "Um tipo de função de callback."
          ],
          "respostaCorreta": "O ciclo que gerencia a execução de tarefas assíncronas."
        },
        {
          "pergunta": "97. O que é o 'Webpack'?",
          "respostas": [
            "Uma ferramenta de empacotamento de módulos JavaScript.",
            "Uma biblioteca para animações.",
            "Um framework para backend.",
            "Uma plataforma para deploy."
          ],
          "respostaCorreta": "Uma ferramenta de empacotamento de módulos JavaScript."
        },
        {
          "pergunta": "98. O que é 'Node.js'?",
          "respostas": [
            "Uma plataforma para desenvolvimento de servidores em JavaScript.",
            "Uma ferramenta para testes automatizados.",
            "Uma linguagem de programação.",
            "Uma biblioteca para front-end."
          ],
          "respostaCorreta": "Uma plataforma para desenvolvimento de servidores em JavaScript."
        },
        {
          "pergunta": "99. Qual é a principal característica do 'React'?",
          "respostas": [
            "Uma biblioteca JavaScript para construção de interfaces de usuário.",
            "Um framework para backend.",
            "Uma ferramenta para animações em CSS.",
            "Uma linguagem de programação."
          ],
          "respostaCorreta": "Uma biblioteca JavaScript para construção de interfaces de usuário."
        },
        {
          "pergunta": "100. O que faz o operador '&&' em JavaScript?",
          "respostas": [
            "Executa uma operação lógica AND.",
            "Compara duas variáveis.",
            "Atribui um valor a uma variável.",
            "Executa um laço de repetição."
          ],
          "respostaCorreta": "Executa uma operação lógica AND."
        },
    ],

  },
];
