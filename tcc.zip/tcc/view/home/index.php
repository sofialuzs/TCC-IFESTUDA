<?php
session_start();
$nomeUsuario = isset($_SESSION['nome']) ? $_SESSION['nome'] : null;

try {
    // Conexão com o banco de dados
    $pdo = new PDO("mysql:host=localhost;dbname=ppi2", "root", "abc@123", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Consulta para obter as disciplinas únicas da tabela 'questoes'
    $stmt = $pdo->query("SELECT DISTINCT disciplina FROM questoes");
    $disciplinas = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Erro ao conectar com o banco de dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>IFEstuda</title>
    <link rel="stylesheet" href="sofi.css" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
  </head>
  <body>
    <nav class="navbar navbar-expand-lg">
      <div class="container-fluid">
        <img src="image-removebg-preview.png" alt="Logo" class="logo" />
        <a class="navbar-brand" href="#">IFEstuda</a>
        <style>
          .logo {
            position: absolute;
            top: 15px;
            left: 15px;
            width: 70px;
            height: auto;
          }
        </style>
      </div>
      
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo $nomeUsuario ? '#.html' : 'login.html'; ?>" id="button-login-usuario">
              <?php echo $nomeUsuario ? $nomeUsuario : 'Login'; ?>
            </a>
          </li>
          <li class="nav-item">
            <?php if ($nomeUsuario): ?>
              <button onclick="excluirSessao()">Sair</button>
            <?php endif; ?>
          </li>
          <li class="nav-item">
            <?php if ($nomeUsuario): ?>
              <a href="../apagarDados.php" class="btn btn-danger btn-sm">Apagar Conta</a>
            <?php endif; ?>
          </li>
        </ul>
      </div>
    </nav>

    <section>
      <div class="content">
        <h1 class="glowing-text">IFEstuda</h1>
        <p>
          Seu portal para estudar e se preparar para as provas de forma
          eficiente!
        </p>
        <a href="#disciplinas" class="btn btn-primary mt-3">Comece a Estudar</a>
      </div>
    </section>

    <section id="disciplinas" class="disciplinas container mt-5" style="margin-bottom: 650px;">
      <div class="row">
        <?php if (!empty($disciplinas)): ?>
          <?php foreach ($disciplinas as $disciplina): ?>
            <div class="col-md-4">
              <div class="card disciplina">
                <h2><?php echo htmlspecialchars($disciplina['disciplina']); ?></h2>
                <p>Explore os tópicos relacionados à disciplina "<?php echo htmlspecialchars($disciplina['disciplina']); ?>" e teste seus conhecimentos.</p>
                <a href="quiz.php?disciplina=<?php echo urlencode($disciplina['disciplina']); ?>" class="btn btn-light estude-btn">Começar Quiz</a>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="text-center">Nenhuma disciplina disponível no momento.</p>
        <?php endif; ?>
      </div>
    </section>
    
    <footer>
      <div class="footer-container">
        <p>&copy; 2024 IFEstuda. Todos os direitos reservados.</p>
      </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
      function excluirSessao() {
        window.location.href = "../excluirSessao.php";
      }
    </script>

    <script type="text/javascript">
      var nomeUsuario = <?php echo isset($_SESSION['nome']) ? json_encode($_SESSION['nome']) : 'null'; ?>;
      if (nomeUsuario) {
        document.getElementById("button-login-usuario").textContent = nomeUsuario;
      }
    </script>

  </body>
</html>
