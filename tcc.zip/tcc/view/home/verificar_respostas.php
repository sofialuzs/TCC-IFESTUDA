<?php
session_start();

// Verifica se houve envio de respostas
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Acesso inválido.");
}

try {
    // Conexão com o banco de dados
    $pdo = new PDO("mysql:host=localhost;dbname=ppi2", "root", "abc@123", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Variáveis para controle de pontuação
    $totalQuestoes = 0;
    $respostasCorretas = 0;

    // Processa cada questão enviada
    foreach ($_POST as $key => $respostaUsuario) {
        // Verifica se a chave corresponde a uma questão (formato: resposta_<id>)
        if (preg_match('/^resposta_(\d+)$/', $key, $matches)) {
            $questaoId = $matches[1];
            $totalQuestoes++;

            // Consulta a resposta correta no banco de dados
            $stmt = $pdo->prepare("SELECT resposta_correta FROM questoes WHERE id = :id");
            $stmt->bindParam(':id', $questaoId, PDO::PARAM_INT);
            $stmt->execute();

	    //print($respostaUsuario)	

            $questao = $stmt->fetch();
            if ($questao && $questao['resposta_correta'] === $respostaUsuario) {
                $respostasCorretas++;
            }
        }
    }

    // Calcula o desempenho
    $percentualAcerto = $totalQuestoes > 0 ? ($respostasCorretas / $totalQuestoes) * 100 : 0;

} catch (PDOException $e) {
    die("Erro ao processar respostas: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado do Quiz</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Resultado do Quiz</h1>

        <div class="alert alert-info text-center">
            <p><strong>Respostas corretas:</strong> <?php echo $respostasCorretas; ?> de <?php echo $totalQuestoes; ?></p>
            <p><strong>Percentual de acerto:</strong> <?php echo round($percentualAcerto, 2); ?>%</p>
        </div>

        <div class="text-center">
            <a href="index.php" class="btn btn-primary">Voltar ao Início</a>
            <a href="quiz.php?disciplina=<?php echo urlencode($_GET['disciplina'] ?? ''); ?>" class="btn btn-secondary">Refazer Quiz</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
