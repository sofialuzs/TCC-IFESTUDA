<?php
session_start();

if (!isset($_GET['disciplina'])) {
    die("Disciplina não especificada.");
}

$disciplina = $_GET['disciplina'];

try {
    // Conexão com o banco de dados
    $pdo = new PDO("mysql:host=localhost:84;dbname=ppi2", "root", "123456", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Consulta as questões da disciplina selecionada
    $stmt = $pdo->prepare("SELECT * FROM questoes WHERE disciplina = :disciplina");
    $stmt->bindParam(':disciplina', $disciplina, PDO::PARAM_STR);
    $stmt->execute();

    $questoes = $stmt->fetchAll();

    if (empty($questoes)) {
        die("Nenhuma questão encontrada para a disciplina selecionada.");
    }

} catch (PDOException $e) {
    die("Erro ao acessar o banco de dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz - <?php echo htmlspecialchars($disciplina); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Quiz: <?php echo htmlspecialchars($disciplina); ?></h1>
        <form action="verificar_respostas.php" method="POST">
            <?php foreach ($questoes as $questao): ?>
                <div class="mb-4">
                    <h5><?php echo htmlspecialchars($questao['id']) . ". " . htmlspecialchars($questao['enunciado']); ?></h5>
                    <div class="form-check">
                        <input type="radio" name="resposta_<?php echo $questao['id']; ?>" value="alternativa_a" id="q<?php echo $questao['id']; ?>_A" class="form-check-input" required>
                        <label for="q<?php echo $questao['id']; ?>_A" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_a']); ?></label>
                    </div>
                    <div class="form-check">
                        <input type="radio" name="resposta_<?php echo $questao['id']; ?>" value="alternativa_b" id="q<?php echo $questao['id']; ?>_B" class="form-check-input" required>
                        <label for="q<?php echo $questao['id']; ?>_B" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_b']); ?></label>
                    </div>
                    <div class="form-check">
                        <input type="radio" name="resposta_<?php echo $questao['id']; ?>" value="alternativa_c" id="q<?php echo $questao['id']; ?>_C" class="form-check-input" required>
                        <label for="q<?php echo $questao['id']; ?>_C" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_c']); ?></label>
                    </div>
                    <div class="form-check">
                        <input type="radio" name="resposta_<?php echo $questao['id']; ?>" value="alternativa_d" id="q<?php echo $questao['id']; ?>_D" class="form-check-input" required>
                        <label for="q<?php echo $questao['id']; ?>_D" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_d']); ?></label>
                    </div>
                </div>
            <?php endforeach; ?>

            <input type="hidden" name="disciplina" value="<?php echo htmlspecialchars($disciplina); ?>">
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Enviar Respostas</button>
                <a href="index.php" class="btn btn-secondary">Cancelar</a>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
