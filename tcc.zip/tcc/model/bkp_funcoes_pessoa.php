<?php

include_once 'modelo_pessoa.php';

class funcoesPessoas {

    function inserir_cadastro($mPes){
        $conexao = new PDO("mysql:dbname=ppi2;localhost:84","root","");
        $sql = "insert into pessoa (email, nome, senha) values ('$mPes->email','$mPes->nome','$mPes->senha')";
        $comando = $conexao->prepare($sql);
        return $comando->execute();

    }

    function verificarEmailCadastro($email){
        $conexao = new PDO("mysql:dbname=ppi2;localhost:84","root","");
        $comando = $conexao->prepare("select * from pessoa");
        $comando->execute();
        $pessoa = $comando->fetchAll(PDO::FETCH_ASSOC);

        foreach($pessoa as $key){
            if($key['email'] == $email){
                ?>
                    <script type="text/javascript">
                    alert("Esse email já existe. Insira outro válido.");
                    window.location = "../view/home/cadastro.html";
                    </script>
                <?php
                break;
            }
        }
    }

    function loginUsuario($email, $senha) {
        try {
            $conexao = new PDO("mysql:dbname=ppi2;localhost:84", "root", "");
            $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "SELECT * FROM pessoa WHERE email = :email AND senha = :senha";
            $comando = $conexao->prepare($sql);
    
            $comando->bindParam(':email', $email, PDO::PARAM_STR);
            $comando->bindParam(':senha', $senha, PDO::PARAM_STR);
            $comando->execute();
            $usuario = $comando->fetch(PDO::FETCH_ASSOC);
    
            if ($usuario) {
                if (!isset($_SESSION)) {
                    session_start();
                }
    
                $_SESSION['email'] = $usuario['email'];
                $_SESSION['nome'] = $usuario['nome'];
                $_SESSION['senha'] = $usuario['senha'];
    
                ?>
                    <script type="text/javascript">
                    alert("O login foi realizado.");
                    window.location = "../view/home/index.php";
                </script>
                <?php                      
            } else {
                ?>
                <script type="text/javascript">
                alert("Email ou senha incorreto. Tente novamente.");
                window.location = "../view/home/login.html";
                </script>
                <?php                      
            }
        } catch (PDOException $e) {
            // Tratamento de erro no banco de dados
            echo "Erro no login: " . $e->getMessage();
        }
    }
    

    function apagarDadosDoUsuario($email){
        try {
            $conexao = new PDO("mysql:dbname=ppi2;localhost:84", "root", "");
            $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "DELETE FROM pessoa WHERE email = :email";
            $comando = $conexao->prepare($sql);
            
            $comando->bindParam(':email', $email, PDO::PARAM_STR);
            return $comando->execute();
        } catch (PDOException $e) {
            // Tratamento de erro
            echo "Erro ao apagar dados do usuário: " . $e->getMessage();
            return false;
        }
    }
    
}


?>