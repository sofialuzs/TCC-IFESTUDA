<?php

include_once '../model/modelo_pessoa.php';
include_once "../model/funcoes_pessoa.php";

$operacao = $_GET['operacao'];

if($operacao == "cadastro"){
    $email = $_POST['email'];
    $nome = $_POST['name'];
    $senha = $_POST['password'];
    $confirmarSenha = $_POST['confirm-password'];

    $fPes = new funcoesPessoas();
    $fPes-> verificarEmailCadastro($email);

    if($senha == $confirmarSenha){
        $mPes = new modeloPessoa($email, $nome, $senha);
        if($fPes->inserir_cadastro($mPes)){
            // Redirecionar para a página de login
            header("Location: ../view/home/login.html");
            exit();
        }
    }else{
        echo "<script>alert('As senhas não coincidem. Por favor, verifique e tente novamente.');</script>";
        echo "<script>window.location = '../view/home/cadastro.html';</script>";
    }
}

if($operacao == "login"){
    $email = $_POST['email'];
    $senha = $_POST['password'];
    $fPes = new funcoesPessoas();
    $fPes-> loginUsuario($email, $senha);
    
}

?>