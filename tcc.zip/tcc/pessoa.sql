create table pessoa( 
    email varchar(255) primary key not null, 
    nome varchar(255) not null, 
    senha varchar(255) not null 
);
