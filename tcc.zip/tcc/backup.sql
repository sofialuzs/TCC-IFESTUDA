DROP TABLE IF EXISTS `pessoa`;

CREATE TABLE `pessoa` (
  `email` varchar(255) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `pessoa` WRITE;

INSERT INTO `pessoa` VALUES
('sofia.luz@ifrn.edu.br','sofia','123456');

UNLOCK TABLES;

DROP TABLE IF EXISTS `questoes`;
CREATE TABLE `questoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `disciplina` varchar(255) NOT NULL,
  `enunciado` text NOT NULL,
  `alternativa_a` text NOT NULL,
  `alternativa_b` text NOT NULL,
  `alternativa_c` text NOT NULL,
  `alternativa_d` text NOT NULL,
  `resposta_correta` enum('alternativa_a','alternativa_b','alternativa_c','alternativa_d') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `questoes` WRITE;

INSERT INTO `questoes` VALUES
(1,'Sistemas Operacionais','O que é um Sistema Operacional?','Um tipo de banco de dados','Software que gerencia hardware e software','Um tipo de linguagem de programação','Um programa de edição de texto','alternativa_b'),
(2,'Sistemas Operacionais','Qual é a principal função de um Sistema Operacional?','Gerenciar recursos do computador','Desenvolver software','Gerenciar a comunicação de redes','Criptografar arquivos','alternativa_a'),
(3,'Sistemas Operacionais','O que é um processo em um Sistema Operacional?','Um tipo de memória','Um arquivo de sistema','Um programa em execução','Um tipo de rede','alternativa_c'),
(4,'Sistemas Operacionais','1. O que é um Sistema Operacional?','Um tipo de banco de dados','Software que gerencia hardware e software','Um tipo de linguagem de programação','Um programa de edição de texto','alternativa_b'),
(5,'Sistemas Operacionais','2. Qual é a principal função de um Sistema Operacional?','Gerenciar recursos do computador','Desenvolver software','Gerenciar a comunicação de redes','Criptografar arquivos','alternativa_a'),
(6,'Sistemas Operacionais','3. O que é um processo em um Sistema Operacional?','Um tipo de memória','Um arquivo de sistema','Um programa em execução','Um tipo de rede','alternativa_c'),
(7,'Sistemas Operacionais','4. O que é um sistema multitarefa?','Sistema que gerencia múltiplos usuários simultaneamente','Sistema que gerencia apenas um tipo de dispositivo','Sistema que gerencia múltiplos processos simultaneamente','Sistema que gerencia apenas um processo por vez','alternativa_c');

UNLOCK TABLES;

DROP TABLE IF EXISTS `questoes_respondidas`;

CREATE TABLE `questoes_respondidas` (
  `usuario_id` varchar(255) NOT NULL,
  `questao_id` int(11) NOT NULL,
  `data_resposta` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`usuario_id`,`questao_id`),
  KEY `questao_id` (`questao_id`),
  CONSTRAINT `questoes_respondidas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `pessoa` (`email`),
  CONSTRAINT `questoes_respondidas_ibfk_2` FOREIGN KEY (`questao_id`) REFERENCES `questoes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


LOCK TABLES `questoes_respondidas` WRITE;
UNLOCK TABLES;

